<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Package;
use App\Models\Service;

class DashboardController extends Controller
{
    public function index()
    {
        $totalPackages = Package::count();
        $totalServices = Service::count();

        return view('dashboard', compact('totalPackages', 'totalServices'));
    }
}

