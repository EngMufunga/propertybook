<?php

namespace App\Http\Controllers;

use App\Models\AboutUsButton;
use Illuminate\Http\Request;

class AboutUsButtonController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Retrieve all AboutUsButtons
        $buttons = AboutUsButton::all();
        return view('about_us_buttons.index', compact('buttons'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create($aboutUsId)
    {
        return view('about_us_buttons.create', compact('aboutUsId'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'about_us_id' => 'required|exists:about_us_sections,id',
            'text' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        AboutUsButton::create($request->all());

        return redirect()->route('about_us_sections.show', $request->about_us_id)
            ->with('success', 'About Us Button created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $button = AboutUsButton::findOrFail($id);
        return view('about_us_buttons.show', compact('button'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $button = AboutUsButton::findOrFail($id);
        return view('about_us_buttons.edit', compact('button'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'text' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $button = AboutUsButton::findOrFail($id);
        $button->update($request->all());

        return redirect()->route('about_us_sections.show', $button->about_us_id)
            ->with('success', 'About Us Button updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $button = AboutUsButton::findOrFail($id);
        $aboutUsId = $button->about_us_id;
        $button->delete();

        return redirect()->route('about_us_sections.show', $aboutUsId)
            ->with('success', 'About Us Button deleted successfully.');
    }
}
