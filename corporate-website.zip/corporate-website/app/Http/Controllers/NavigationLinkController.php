<?php

namespace App\Http\Controllers;

use App\Models\NavigationLink;
use Illuminate\Http\Request;

class NavigationLinkController extends Controller
{

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $links = NavigationLink::all();
        return view('navigation_links.index', compact('links'));
    }
 

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('navigation_links.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'text' => 'required|string|max:255',
            'url' => 'required|string|max:255',
            'order' => 'required|integer',
        ]);

        NavigationLink::create($request->all());

        return redirect()->route('links.index')
            ->with('success', 'Navigation link created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $link = NavigationLink::findOrFail($id);
        return view('navigation_links.show', compact('link'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $link = NavigationLink::findOrFail($id);
        return view('navigation_links.edit', compact('link'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'text' => 'required|string|max:255',
            'url' => 'required|string|max:255',
            'order' => 'required|integer',
        ]);

        $link = NavigationLink::findOrFail($id);
        $link->update($request->all());

        return redirect()->route('links.index')
            ->with('success', 'Navigation link updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $link = NavigationLink::findOrFail($id);
        $link->delete();

        return redirect()->route('links.index')
            ->with('success', 'Navigation link deleted successfully.');
    }
}
