<?php

namespace App\Http\Controllers;

use App\Models\HeroSection;
use Illuminate\Http\Request;

class HeroSectionController extends Controller
{

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $sections = HeroSection::all();
        return view('hero_section.index', compact('sections'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('hero_section.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'button1_text' => 'required|string|max:255',
            'button1_url' => 'required|string|max:255',
            'button2_text' => 'nullable|string|max:255',
            'button2_url' => 'nullable|string|max:255',
            'image_path' => 'nullable|string|max:255',
        ]);

        HeroSection::create($request->all());

        return redirect()->route('hero_section.index')
            ->with('success', 'Hero section created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $section = HeroSection::findOrFail($id);
        return view('hero_section.show', compact('section'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $section = HeroSection::findOrFail($id);
        return view('hero_section.edit', compact('section'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'button1_text' => 'required|string|max:255',
            'button1_url' => 'required|string|max:255',
            'button2_text' => 'nullable|string|max:255',
            'button2_url' => 'nullable|string|max:255',
            'image_path' => 'nullable|string|max:255',
        ]);

        $section = HeroSection::findOrFail($id);
        $section->update($request->all());

        return redirect()->route('hero_section.index')
            ->with('success', 'Hero section updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $section = HeroSection::findOrFail($id);
        $section->delete();

        return redirect()->route('hero_section.index')
            ->with('success', 'Hero section deleted successfully.');
    }
}

