<?php

namespace App\Http\Controllers;

use App\Models\AboutUsSection;
use Illuminate\Http\Request;

class AboutUsSectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $sections = AboutUsSection::all();
        return view('about_us_sections.index', compact('sections'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('about_us_sections.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image_path' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Example validation for image upload
        ]);

        // Handle image upload if needed
        if ($request->hasFile('image_path')) {
            $imagePath = $request->file('image_path')->store('about_us_images');
        } else {
            $imagePath = null;
        }

        $section = AboutUsSection::create([
            'title' => $request->title,
            'description' => $request->description,
            'image_path' => $imagePath,
        ]);

        return redirect()->route('about_us_sections.index')
            ->with('success', 'About Us section created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $section = AboutUsSection::findOrFail($id);
        return view('about_us_sections.show', compact('section'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $section = AboutUsSection::findOrFail($id);
        return view('about_us_sections.edit', compact('section'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image_path' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Example validation for image upload
        ]);

        $section = AboutUsSection::findOrFail($id);

        // Handle image update if needed
        if ($request->hasFile('image_path')) {
            $imagePath = $request->file('image_path')->store('about_us_images');
            // Delete old image if exists
            if ($section->image_path) {
                Storage::delete($section->image_path);
            }
            $section->image_path = $imagePath;
        }

        $section->title = $request->title;
        $section->description = $request->description;
        $section->save();

        return redirect()->route('about_us_sections.index')
            ->with('success', 'About Us section updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $section = AboutUsSection::findOrFail($id);

        // Delete associated buttons if needed
        $section->buttons()->delete();

        // Delete image if exists
        if ($section->image_path) {
            Storage::delete($section->image_path);
        }

        $section->delete();

        return redirect()->route('about_us_sections.index')
            ->with('success', 'About Us section deleted successfully.');
    }
}
