<?php

namespace App\Http\Controllers;

use App\Models\PackageFeature;
use Illuminate\Http\Request;

class PackageFeatureController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $features = PackageFeature::all();
        return view('package_features.index', compact('features'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('package_features.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'feature' => 'required|string',
        ]);

        PackageFeature::create($request->all());

        return redirect()->route('features.index')
            ->with('success', 'Package feature created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $feature = PackageFeature::findOrFail($id);
        return view('package_features.show', compact('feature'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $feature = PackageFeature::findOrFail($id);
        return view('package_features.edit', compact('feature'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'feature' => 'required|string',
        ]);

        $feature = PackageFeature::findOrFail($id);
        $feature->update($request->all());

        return redirect()->route('features.index')
            ->with('success', 'Package feature updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $feature = PackageFeature::findOrFail($id);
        $feature->delete();

        return redirect()->route('features.index')
            ->with('success', 'Package feature deleted successfully.');
    }
}
