<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AboutUsSection extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'description', 'image_path'];

    public function buttons()
    {
        return $this->hasMany(AboutUsButton::class, 'about_us_id');
    }
}
