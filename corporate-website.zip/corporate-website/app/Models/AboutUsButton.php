<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AboutUsButton extends Model
{
    use HasFactory;

    protected $fillable = ['about_us_id', 'text', 'content'];

    public function aboutUsSection()
    {
        return $this->belongsTo(AboutUsSection::class, 'about_us_id');
    }
}
