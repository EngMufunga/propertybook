document.addEventListener("DOMContentLoaded", function() {
"use strict";

// Function to handle sticky navbar on scroll
function handleStickyNavbar() {
  const headerNavbar = document.querySelector(".navbar-area");
  const sticky = headerNavbar.offsetTop;

  if (window.pageYOffset > sticky) {
    headerNavbar.classList.add("sticky");
  } else {
    headerNavbar.classList.remove("sticky");
  }
}

// Function to handle active navigation links on scroll
function handleActiveNavigationLinks() {
  const sections = document.querySelectorAll('.page-scroll');
  const scrollPos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;

  for (let sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
    const currentLink = sections[sectionIndex];
    const sectionHref = currentLink.getAttribute('href');
    const refElement = document.querySelector(sectionHref);
    const scrollTopMinus = scrollPos + 73;

    if (refElement.offsetTop <= scrollTopMinus && (refElement.offsetTop + refElement.offsetHeight > scrollTopMinus)) {
      document.querySelector('.page-scroll').classList.remove('active');
      currentLink.classList.add('active');
    } else {
      currentLink.classList.remove('active');
    }
  }
}

// Event listeners
window.onscroll = function () {
  handleStickyNavbar();
  handleActiveNavigationLinks();
};

// Smooth scrolling for navigation links
const pageLink = document.querySelectorAll('.page-scroll');

pageLink.forEach(elem => {
  elem.addEventListener('click', (e) => {
    e.preventDefault();
    document.querySelector(elem.getAttribute('href')).scrollIntoView({ behavior: 'smooth', offsetTop: 1 - 60 });
  });
});


});