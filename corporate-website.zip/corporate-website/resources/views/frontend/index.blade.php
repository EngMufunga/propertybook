<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/images/favicon.svg') }}" />

  <title>Corporate Website</title>

  <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/lineicons.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/tiny-slider.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/glightbox.min.css') }}" />
  <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}" />
</head>
<body>

<section class="navbar-area navbar-nine">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="{{ route('home') }}">
                            <img src="assets/images/white-logo.svg" alt="Logo" />
                        </a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNine" aria-controls="navbarNine" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarNine">
                            <ul class="navbar-nav me-auto">
                                @foreach($links as $link)
                                    <li class="nav-item">
                                        <a class="page-scroll {{ $loop->first ? 'active' : '' }}" href="{{ $link->url }}">{{ $link->text }}</a>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                        <div class="navbar-btn d-none d-lg-inline-block">
                            <a class="menu-bar" href="#side-menu-left"><i class="lni lni-menu"></i></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </section>






<div class="sidebar-left">
<div class="sidebar-close">
<a class="close" href="#close"><i class="lni lni-close"></i></a>
</div>
<div class="sidebar-content">
<div class="sidebar-logo">
<a href="index.html"><img src="assets/images/logo.svg" alt="Logo" /></a>
</div>


<div class="sidebar-menu">

<ul>
<li><a href="#services">Home</a></li>
<li><a href="#services">Services</a></li>
<li><a href="#services">Packages</a></li>
</ul>
</div>

</div>

</div>
<div class="overlay-left"></div>


<section id="hero-area" class="header-area header-eight">
        <div class="container">
            <div class="row align-items-center">
                @foreach ($sections as $section)
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="header-content">
                            <h1>{{ $section->title }}</h1>
                            <p>{{ $section->description }}</p>
                            <div class="button">
                                @if ($section->button1_text && $section->button1_url)
                                    <a href="{{ $section->button1_url }}" class="btn primary-btn">{{ $section->button1_text }}</a>
                                @endif
                                @if ($section->button2_text && $section->button2_url)
                                    <a href="{{ $section->button2_url }}" class="glightbox video-button">
                                        <span class="btn icon-btn rounded-full">
                                            <i class="lni lni-play"></i>
                                        </span>
                                        <span class="text">{{ $section->button2_text }}</span>
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="header-image">
                            <img src="{{ asset($section->image_path) }}" alt="#" />
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>


<section class="about-area about-five">
        <div class="container">
            <div class="row align-items-center">
                @foreach ($sections as $section)
                    <div class="col-lg-6 col-12">
                        <div class="about-image-five">
                            <svg class="shape" width="106" height="134" viewBox="0 0 106 134" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="1.66654" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="132" r="1.66667" fill="#DADADA" />
                            </svg>
                            <img src="{{ asset($section->image_path) }}" alt="about" />
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="about-five-content">
                            <h6 class="small-title text-lg">{{ $section->title }}</h6>
                            <h2 class="main-title fw-bold">{{ $section->description }}</h2>
                            <div class="about-five-tab">
                                <nav>
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        @foreach ($section->buttons as $button)
                                            <button class="nav-link {{ $loop->first ? 'active' : '' }}" id="nav-{{ Str::slug($button->text) }}-tab" data-bs-toggle="tab" data-bs-target="#nav-{{ Str::slug($button->text) }}" type="button" role="tab" aria-controls="nav-{{ Str::slug($button->text) }}" aria-selected="{{ $loop->first ? 'true' : 'false' }}">{{ $button->text }}</button>
                                        @endforeach
                                    </div>
                                </nav>
                                <div class="tab-content" id="nav-tabContent">
                                    @foreach ($section->buttons as $button)
                                        <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }}" id="nav-{{ Str::slug($button->text) }}" role="tabpanel" aria-labelledby="nav-{{ Str::slug($button->text) }}-tab">
                                            {!! $button->content !!}
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>


    <section id="services" class="services-area services-eight">

        <div class="section-title-five">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="content">
                            <h6>Services</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                @foreach ($services as $service)
                    <div class="col-lg-4 col-md-6">
                        <div class="single-services">
                            <div class="service-icon">
                                <i class="{{ $service->icon }}"></i>
                            </div>
                            <div class="service-content">
                                <h4>{{ $service->title }}</h4>
                                <p>{{ $service->description }}</p>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

    </section>




    <section id="pricing" class="pricing-area pricing-fourteen">

<div class="section-title-five">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="content">
                    <h6>Pricing</h6>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        @foreach ($packages as $package)
            <div class="col-lg-4 col-md-6 col-12">
                <div class="pricing-style-fourteen">
                    <div class="table-head">
                        <h6 class="title">{{ $package->title }}</h6>
                        <p>{{ $package->description }}</p>
                        <div class="price">
                            <h2 class="amount">
                                <span class="currency">$</span>{{ $package->price }}
                                <span class="duration">/mo </span>
                            </h2>
                        </div>
                    </div>
                    <div class="light-rounded-buttons">
                        <a href="javascript:void(0)" class="btn primary-btn-outline">
                            Start free trial
                        </a>
                    </div>
                    <div class="table-content">
                        <ul class="table-list">
                            @foreach ($package->features as $feature)
                                <li>
                                    <i class="lni {{ $feature->active ? 'lni-checkmark-circle' : 'lni-checkmark-circle deactive' }}"></i>
                                    {{ $feature->feature }}
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>

</section>


<section id="call-action" class="call-action">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-6 col-xl-7 col-lg-8 col-md-9">
                    <div class="inner-content">
                        @foreach ($footers as $footer)
                            <h2>{{ $footer->title }}</h2>
                            <p>{{ $footer->text }}</p>
                            <div class="light-rounded-buttons">
                                <a href="{{ $footer->button_url }}" class="btn primary-btn-outline">{{ $footer->button_text }}</a>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>


<script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/js/glightbox.min.js') }}"></script>
<script src="{{ asset('assets/js/tiny-slider.js') }}"></script>
<script src="{{ asset('assets/js/main.js') }}"></script>
<script>

    let navbarTogglerNine = document.querySelector(
      ".navbar-nine .navbar-toggler"
    );
    navbarTogglerNine.addEventListener("click", function () {
      navbarTogglerNine.classList.toggle("active");
    });

   
    let sidebarLeft = document.querySelector(".sidebar-left");
    let overlayLeft = document.querySelector(".overlay-left");
    let sidebarClose = document.querySelector(".sidebar-close .close");
   


    overlayLeft.addEventListener("click", function () {
      sidebarLeft.classList.toggle("open");
      overlayLeft.classList.toggle("open");
    });
    sidebarClose.addEventListener("click", function () {
      sidebarLeft.classList.remove("open");
      overlayLeft.classList.remove("open");
    });

    
    let sideMenuLeftNine = document.querySelector(".navbar-nine .menu-bar");

    sideMenuLeftNine.addEventListener("click", function () {
      sidebarLeft.classList.add("open");
      overlayLeft.classList.add("open");
    });

    $('#nav-tab a').on('click', function (e) {
    e.preventDefault();
    
    $(this).tab('show');
});


   
   
  </script>
<script src="../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" defer></script></body>

</html>