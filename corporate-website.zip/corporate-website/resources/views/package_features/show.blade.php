@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Package Feature Details</h1>
        <p><strong>Feature:</strong> {{ $feature->feature }}</p>
        <a href="{{ route('features.index') }}" class="btn btn-primary">Back to Package Features</a>
    </div>
@endsection
