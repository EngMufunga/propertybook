@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Create New Package Feature</h1>
        <form action="{{ route('features.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="feature" class="form-label">Feature</label>
                <input type="text" class="form-control" id="feature" name="feature">
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
@endsection
