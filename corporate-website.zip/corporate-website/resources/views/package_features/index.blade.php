@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Package Features</h1>
        <a href="{{ route('features.create') }}" class="btn btn-primary">Create New Package Feature</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Feature</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($features as $feature)
                    <tr>
                        <td>{{ $feature->feature }}</td>
                        <td>
                            <a href="{{ route('features.show', $feature->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('features.edit', $feature->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('features.destroy', $feature->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
