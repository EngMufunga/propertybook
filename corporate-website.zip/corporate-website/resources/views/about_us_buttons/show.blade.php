@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>About Us Button Details</h1>
        <p><strong>ID:</strong> {{ $button->id }}</p>
        <p><strong>Text:</strong> {{ $button->text }}</p>
        <p><strong>Content:</strong> {{ $button->content }}</p>
        <a href="{{ route('about_us_sections.show', $button->aboutUsSection->id) }}" class="btn btn-primary">Back to About Us Section</a>
    </div>
@endsection
