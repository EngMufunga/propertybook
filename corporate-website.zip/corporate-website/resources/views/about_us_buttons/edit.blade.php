@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Edit About Us Button</h1>
        <form action="{{ route('about_us_buttons.update', $button->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label for="text" class="form-label">Text</label>
                <input type="text" class="form-control" id="text" name="text" value="{{ $button->text }}">
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" id="content" name="content">{{ $button->content }}</textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
@endsection
