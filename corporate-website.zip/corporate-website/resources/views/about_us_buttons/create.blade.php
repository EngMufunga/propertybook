@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Create New About Us Button</h1>
        <form action="{{ route('about_us_buttons.store') }}" method="POST">
            @csrf
            <input type="hidden" name="about_us_id" value="{{ $aboutUsId }}">
            <div class="mb-3">
                <label for="text" class="form-label">Text</label>
                <input type="text" class="form-control" id="text" name="text">
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Content</label>
                <textarea class="form-control" id="content" name="content"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
@endsection
