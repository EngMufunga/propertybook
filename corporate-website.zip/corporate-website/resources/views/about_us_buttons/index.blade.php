@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>About Us Buttons</h1>
        <a href="{{ route('about_us_buttons.create', $aboutUsId) }}" class="btn btn-primary">Create New Button</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Text</th>
                    <th>Content</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($buttons as $button)
                    <tr>
                        <td>{{ $button->id }}</td>
                        <td>{{ $button->text }}</td>
                        <td>{{ $button->content }}</td>
                        <td>
                            <a href="{{ route('about_us_buttons.show', $button->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('about_us_buttons.edit', $button->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('about_us_buttons.destroy', $button->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
