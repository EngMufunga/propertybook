<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      {{ __('Dashboard') }}
    </h2>
  </x-slot>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3">
        <div class="list-group mb-3">
          <a href="{{ route('dashboard') }}" class="list-group-item list-group-item-action {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            Dashboard
          </a>
          <a href="#" class="list-group-item list-group-item-action">
            Total Packages: <span class="badge bg-primary">{{ $totalPackages }}</span>
          </a>
          <a href="#" class="list-group-item list-group-item-action">
            Total Services: <span class="badge bg-success">{{ $totalServices }}</span>
          </a>

          <a href="{{ route('hero_section.index') }}" class="list-group-item list-group-item-action">Hero Section</a>
          <a href="{{ route('about_us_sections.index') }}" class="list-group-item list-group-item-action">Our Story Section</a>
          <a href="{{ route('services.index') }}" class="list-group-item list-group-item-action">Services Section</a>
          <a href="{{ route('packages.index') }}" class="list-group-item list-group-item-action">Packages Section</a>
          <a href="{{ route('footers.index') }}" class="list-group-item list-group-item-action">Call to Action Section</a>
        </div>
      </div>

      <div class="col-md-9">
        <div class="card-deck">
          <div class="card mb-3">
            <div class="card-header bg-primary text-white">
              Total Packages
            </div>
            <div class="card-body">
              <h5 class="card-title">{{ $totalPackages }}</h5>
            </div>
          </div>
          <div class="card mb-3">
            <div class="card-header bg-success text-white">
              Total Services
            </div>
            <div class="card-body">
              <h5 class="card-title">{{ $totalServices }}</h5>
            </div>
          </div>
        </div>

        <div class="mt-4">
          </div>
      </div>
    </div>
  </div>

  <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}"></script>
</x-app-layout>
