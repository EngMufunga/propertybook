@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>About Us Section Details</h1>
        <p><strong>Title:</strong> {{ $section->title }}</p>
        <p><strong>Description:</strong> {{ $section->description }}</p>
        @if ($section->image_path)
            <p><strong>Image:</strong></p>
            <div>
                <img src="{{ asset('storage/' . $section->image_path) }}" alt="Image" style="max-width: 400px;">
            </div>
        @endif
        <a href="{{ route('about_us_sections.index') }}" class="btn btn-primary">Back to Sections</a>
    </div>
@endsection
