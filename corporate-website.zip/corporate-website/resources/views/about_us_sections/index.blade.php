@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>About Us Sections</h1>
        <a href="{{ route('about_us_sections.create') }}" class="btn btn-primary">Create New Section</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($sections as $section)
                    <tr>
                        <td>{{ $section->title }}</td>
                        <td>{{ $section->description }}</td>
                        <td>
                            @if ($section->image_path)
                                <img src="{{ asset('storage/' . $section->image_path) }}" alt="Image" style="max-width: 100px;">
                            @else
                                No image
                            @endif
                        </td>
                        <td>
                            <a href="{{ route('about_us_sections.show', $section->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('about_us_sections.edit', $section->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('about_us_sections.destroy', $section->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
