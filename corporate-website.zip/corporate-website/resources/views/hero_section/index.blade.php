@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Hero Sections</h1>
        <a href="{{ route('hero_sections.create') }}" class="btn btn-primary">Create New Hero Section</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Button 1 Text</th>
                    <th>Button 1 URL</th>
                    <th>Button 2 Text</th>
                    <th>Button 2 URL</th>
                    <th>Image Path</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($sections as $section)
                    <tr>
                        <td>{{ $section->title }}</td>
                        <td>{{ $section->description }}</td>
                        <td>{{ $section->button1_text }}</td>
                        <td>{{ $section->button1_url }}</td>
                        <td>{{ $section->button2_text }}</td>
                        <td>{{ $section->button2_url }}</td>
                        <td>{{ $section->image_path }}</td>
                        <td>
                            <a href="{{ route('hero_sections.show', $section->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('hero_sections.edit', $section->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('hero_sections.destroy', $section->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
