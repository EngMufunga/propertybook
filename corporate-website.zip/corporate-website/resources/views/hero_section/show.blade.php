@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Hero Section Details</h1>
        <p><strong>Title:</strong> {{ $section->title }}</p>
        <p><strong>Description:</strong> {{ $section->description }}</p>
        <p><strong>Button 1 Text:</strong> {{ $section->button1_text }}</p>
        <p><strong>Button 1 URL:</strong> {{ $section->button1_url }}</p>
        <p><strong>Button 2 Text:</strong> {{ $section->button2_text }}</p>
        <p><strong>Button 2 URL:</strong> {{ $section->button2_url }}</p>
        <p><strong>Image Path:</strong> {{ $section->image_path }}</p>
        <a href="{{ route('hero_sections.index') }}" class="btn btn-primary">Back to Hero Sections</a>
    </div>
@endsection
