@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Create New Hero Section</h1>
        <form action="{{ route('hero_sections.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title">
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description"></textarea>
            </div>
            <div class="mb-3">
                <label for="button1_text" class="form-label">Button 1 Text</label>
                <input type="text" class="form-control" id="button1_text" name="button1_text">
            </div>
            <div class="mb-3">
                <label for="button1_url" class="form-label">Button 1 URL</label>
                <input type="text" class="form-control" id="button1_url" name="button1_url">
            </div>
            <div class="mb-3">
                <label for="button2_text" class="form-label">Button 2 Text</label>
                <input type="text" class="form-control" id="button2_text" name="button2_text">
            </div>
            <div class="mb-3">
                <label for="button2_url" class="form-label">Button 2 URL</label>
                <input type="text" class="form-control" id="button2_url" name="button2_url">
            </div>
            <div class="mb-3">
                <label for="image_path" class="form-label">Image Path</label>
                <input type="text" class="form-control" id="image_path" name="image_path">
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
@endsection
