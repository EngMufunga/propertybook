@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Create New Footer</h1>
        <form action="{{ route('footers.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title">
            </div>
            <div class="mb-3">
                <label for="text" class="form-label">Text</label>
                <textarea class="form-control" id="text" name="text"></textarea>
            </div>
            <div class="mb-3">
                <label for="button_text" class="form-label">Button Text</label>
                <input type="text" class="form-control" id="button_text" name="button_text">
            </div>
            <div class="mb-3">
                <label for="button_url" class="form-label">Button URL</label>
                <input type="text" class="form-control" id="button_url" name="button_url">
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
@endsection
