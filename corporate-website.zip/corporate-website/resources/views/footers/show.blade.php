@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Footer Details</h1>
        <p><strong>Title:</strong> {{ $footer->title }}</p>
        <p><strong>Text:</strong> {{ $footer->text }}</p>
        <p><strong>Button Text:</strong> {{ $footer->button_text }}</p>
        <p><strong>Button URL:</strong> {{ $footer->button_url }}</p>
        <a href="{{ route('footers.index') }}" class="btn btn-primary">Back to Footers</a>
    </div>
@endsection
