@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Edit Footer</h1>
        <form action="{{ route('footers.update', $footer->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" value="{{ $footer->title }}">
            </div>
            <div class="mb-3">
                <label for="text" class="form-label">Text</label>
                <textarea class="form-control" id="text" name="text">{{ $footer->text }}</textarea>
            </div>
            <div class="mb-3">
                <label for="button_text" class="form-label">Button Text</label>
                <input type="text" class="form-control" id="button_text" name="button_text" value="{{ $footer->button_text }}">
            </div>
            <div class="mb-3">
                <label for="button_url" class="form-label">Button URL</label>
                <input type="text" class="form-control" id="button_url" name="button_url" value="{{ $footer->button_url }}">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
@endsection
