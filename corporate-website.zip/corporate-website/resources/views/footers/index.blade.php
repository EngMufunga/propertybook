@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Footers</h1>
        <a href="{{ route('footers.create') }}" class="btn btn-primary">Create New Footer</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Text</th>
                    <th>Button Text</th>
                    <th>Button URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($footers as $footer)
                    <tr>
                        <td>{{ $footer->title }}</td>
                        <td>{{ $footer->text }}</td>
                        <td>{{ $footer->button_text }}</td>
                        <td>{{ $footer->button_url }}</td>
                        <td>
                            <a href="{{ route('footers.show', $footer->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('footers.edit', $footer->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('footers.destroy', $footer->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
