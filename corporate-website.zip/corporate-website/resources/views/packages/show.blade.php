@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Package Details</h1>
        <p><strong>Title:</strong> {{ $package->title }}</p>
        <p><strong>Description:</strong> {{ $package->description }}</p>
        <p><strong>Price:</strong> {{ $package->price }}</p>
        <a href="{{ route('packages.index') }}" class="btn btn-primary">Back to Packages</a>
    </div>
@endsection
