@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Packages</h1>
        <a href="{{ route('packages.create') }}" class="btn btn-primary">Create New Package</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($packages as $package)
                    <tr>
                        <td>{{ $package->title }}</td>
                        <td>{{ $package->description }}</td>
                        <td>{{ $package->price }}</td>
                        <td>
                            <a href="{{ route('packages.show', $package->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('packages.edit', $package->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('packages.destroy', $package->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
