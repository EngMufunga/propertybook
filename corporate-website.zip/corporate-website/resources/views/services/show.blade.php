@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Service Details</h1>
        <p><strong>Icon:</strong> {{ $service->icon }}</p>
        <p><strong>Title:</strong> {{ $service->title }}</p>
        <p><strong>Description:</strong> {{ $service->description }}</p>
        <a href="{{ route('services.index') }}" class="btn btn-primary">Back to Services</a>
    </div>
@endsection
