@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Navigation Link Details</h1>
        <p><strong>Text:</strong> {{ $link->text }}</p>
        <p><strong>URL:</strong> {{ $link->url }}</p>
        <p><strong>Order:</strong> {{ $link->order }}</p>
        <a href="{{ route('links.index') }}" class="btn btn-primary">Back to Navigation Links</a>
    </div>
@endsection
