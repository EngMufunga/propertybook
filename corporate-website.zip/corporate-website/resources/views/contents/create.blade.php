@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Create New Content</h1>
        <form action="{{ route('contents.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label for="section" class="form-label">Section</label>
                <input type="text" class="form-control" id="section" name="section">
            </div>
            <div class="mb-3">
                <label for="text" class="form-label">Text</label>
                <textarea class="form-control" id="text" name="text"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
@endsection
