@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Content Details</h1>
        <p><strong>Section:</strong> {{ $content->section }}</p>
        <p><strong>Text:</strong> {{ $content->text }}</p>
        <a href="{{ route('contents.index') }}" class="btn btn-primary">Back to Contents</a>
    </div>
@endsection
