@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Contents</h1>
        <a href="{{ route('contents.create') }}" class="btn btn-primary">Create New Content</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Section</th>
                    <th>Text</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($contents as $content)
                    <tr>
                        <td>{{ $content->section }}</td>
                        <td>{{ $content->text }}</td>
                        <td>
                            <a href="{{ route('contents.show', $content->id) }}" class="btn btn-info">Show</a>
                            <a href="{{ route('contents.edit', $content->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('contents.destroy', $content->id) }}" method="POST" style="display:inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
