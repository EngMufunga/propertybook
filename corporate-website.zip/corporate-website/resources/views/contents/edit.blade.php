@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Edit Content</h1>
        <form action="{{ route('contents.update', $content->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="mb-3">
                <label for="section" class="form-label">Section</label>
                <input type="text" class="form-control" id="section" name="section" value="{{ $content->section }}">
            </div>
            <div class="mb-3">
                <label for="text" class="form-label">Text</label>
                <textarea class="form-control" id="text" name="text">{{ $content->text }}</textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
@endsection
