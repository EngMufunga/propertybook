

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>About Us Sections</h1>
        <a href="<?php echo e(route('about_us_sections.create')); ?>" class="btn btn-primary">Create New Section</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($section->title); ?></td>
                        <td><?php echo e($section->description); ?></td>
                        <td>
                            <?php if($section->image_path): ?>
                                <img src="<?php echo e(asset('storage/' . $section->image_path)); ?>" alt="Image" style="max-width: 100px;">
                            <?php else: ?>
                                No image
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('about_us_sections.show', $section->id)); ?>" class="btn btn-info">Show</a>
                            <a href="<?php echo e(route('about_us_sections.edit', $section->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('about_us_sections.destroy', $section->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wilson Mufunga\Desktop\corporate-website\resources\views/about_us_sections/index.blade.php ENDPATH**/ ?>