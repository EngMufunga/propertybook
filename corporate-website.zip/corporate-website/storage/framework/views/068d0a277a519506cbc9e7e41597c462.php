<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
  <meta charset="utf-8" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <meta name="description" content="" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.svg')); ?>" />

  <title>Corporate Website</title>

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/lineicons.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/tiny-slider.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/glightbox.min.css')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
</head>
<body>

<section class="navbar-area navbar-nine">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                            <img src="assets/images/white-logo.svg" alt="Logo" />
                        </a>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNine" aria-controls="navbarNine" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarNine">
                            <ul class="navbar-nav me-auto">
                                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="page-scroll <?php echo e($loop->first ? 'active' : ''); ?>" href="<?php echo e($link->url); ?>"><?php echo e($link->text); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="navbar-btn d-none d-lg-inline-block">
                            <a class="menu-bar" href="#side-menu-left"><i class="lni lni-menu"></i></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </section>






<div class="sidebar-left">
<div class="sidebar-close">
<a class="close" href="#close"><i class="lni lni-close"></i></a>
</div>
<div class="sidebar-content">
<div class="sidebar-logo">
<a href="index.html"><img src="assets/images/logo.svg" alt="Logo" /></a>
</div>


<div class="sidebar-menu">

<ul>
<li><a href="#services">Home</a></li>
<li><a href="#services">Services</a></li>
<li><a href="#services">Packages</a></li>
</ul>
</div>

</div>

</div>
<div class="overlay-left"></div>


<section id="hero-area" class="header-area header-eight">
        <div class="container">
            <div class="row align-items-center">
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="header-content">
                            <h1><?php echo e($section->title); ?></h1>
                            <p><?php echo e($section->description); ?></p>
                            <div class="button">
                                <?php if($section->button1_text && $section->button1_url): ?>
                                    <a href="<?php echo e($section->button1_url); ?>" class="btn primary-btn"><?php echo e($section->button1_text); ?></a>
                                <?php endif; ?>
                                <?php if($section->button2_text && $section->button2_url): ?>
                                    <a href="<?php echo e($section->button2_url); ?>" class="glightbox video-button">
                                        <span class="btn icon-btn rounded-full">
                                            <i class="lni lni-play"></i>
                                        </span>
                                        <span class="text"><?php echo e($section->button2_text); ?></span>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="header-image">
                            <img src="<?php echo e(asset($section->image_path)); ?>" alt="#" />
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


<section class="about-area about-five">
        <div class="container">
            <div class="row align-items-center">
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-12">
                        <div class="about-image-five">
                            <svg class="shape" width="106" height="134" viewBox="0 0 106 134" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="1.66654" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="1.66654" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="16.3333" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="16.333" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="30.9998" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="74.6665" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="31" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="74.6668" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="45.6665" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="89.3333" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="1.66679" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="16.3335" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="31.0001" r="1.66667" fill="#DADADA" />
<circle cx="60.3333" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="45.6668" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="60.3335" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="88.6668" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="117.667" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="74.6668" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="103" r="1.66667" fill="#DADADA" />
<circle cx="60.333" cy="132" r="1.66667" fill="#DADADA" />
<circle cx="104" cy="132" r="1.66667" fill="#DADADA" />
                            </svg>
                            <img src="<?php echo e(asset($section->image_path)); ?>" alt="about" />
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="about-five-content">
                            <h6 class="small-title text-lg"><?php echo e($section->title); ?></h6>
                            <h2 class="main-title fw-bold"><?php echo e($section->description); ?></h2>
                            <div class="about-five-tab">
                                <nav>
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        <?php $__currentLoopData = $section->buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="nav-<?php echo e(Str::slug($button->text)); ?>-tab" data-bs-toggle="tab" data-bs-target="#nav-<?php echo e(Str::slug($button->text)); ?>" type="button" role="tab" aria-controls="nav-<?php echo e(Str::slug($button->text)); ?>" aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($button->text); ?></button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </nav>
                                <div class="tab-content" id="nav-tabContent">
                                    <?php $__currentLoopData = $section->buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="nav-<?php echo e(Str::slug($button->text)); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e(Str::slug($button->text)); ?>-tab">
                                            <?php echo $button->content; ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


    <section id="services" class="services-area services-eight">

        <div class="section-title-five">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="content">
                            <h6>Services</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-services">
                            <div class="service-icon">
                                <i class="<?php echo e($service->icon); ?>"></i>
                            </div>
                            <div class="service-content">
                                <h4><?php echo e($service->title); ?></h4>
                                <p><?php echo e($service->description); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </section>




    <section id="pricing" class="pricing-area pricing-fourteen">

<div class="section-title-five">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="content">
                    <h6>Pricing</h6>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
                <div class="pricing-style-fourteen">
                    <div class="table-head">
                        <h6 class="title"><?php echo e($package->title); ?></h6>
                        <p><?php echo e($package->description); ?></p>
                        <div class="price">
                            <h2 class="amount">
                                <span class="currency">$</span><?php echo e($package->price); ?>

                                <span class="duration">/mo </span>
                            </h2>
                        </div>
                    </div>
                    <div class="light-rounded-buttons">
                        <a href="javascript:void(0)" class="btn primary-btn-outline">
                            Start free trial
                        </a>
                    </div>
                    <div class="table-content">
                        <ul class="table-list">
                            <?php $__currentLoopData = $package->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <i class="lni <?php echo e($feature->active ? 'lni-checkmark-circle' : 'lni-checkmark-circle deactive'); ?>"></i>
                                    <?php echo e($feature->feature); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

</section>


<section id="call-action" class="call-action">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-6 col-xl-7 col-lg-8 col-md-9">
                    <div class="inner-content">
                        <?php $__currentLoopData = $footers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2><?php echo e($footer->title); ?></h2>
                            <p><?php echo e($footer->text); ?></p>
                            <div class="light-rounded-buttons">
                                <a href="<?php echo e($footer->button_url); ?>" class="btn primary-btn-outline"><?php echo e($footer->button_text); ?></a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>


<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/glightbox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/tiny-slider.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<script>

    let navbarTogglerNine = document.querySelector(
      ".navbar-nine .navbar-toggler"
    );
    navbarTogglerNine.addEventListener("click", function () {
      navbarTogglerNine.classList.toggle("active");
    });

   
    let sidebarLeft = document.querySelector(".sidebar-left");
    let overlayLeft = document.querySelector(".overlay-left");
    let sidebarClose = document.querySelector(".sidebar-close .close");
   


    overlayLeft.addEventListener("click", function () {
      sidebarLeft.classList.toggle("open");
      overlayLeft.classList.toggle("open");
    });
    sidebarClose.addEventListener("click", function () {
      sidebarLeft.classList.remove("open");
      overlayLeft.classList.remove("open");
    });

    
    let sideMenuLeftNine = document.querySelector(".navbar-nine .menu-bar");

    sideMenuLeftNine.addEventListener("click", function () {
      sidebarLeft.classList.add("open");
      overlayLeft.classList.add("open");
    });

    $('#nav-tab a').on('click', function (e) {
    e.preventDefault();
    
    $(this).tab('show');
});


   
   
  </script>
<script src="../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" defer></script></body>

</html><?php /**PATH C:\Users\Wilson Mufunga\Desktop\corporate-website\resources\views/frontend/index.blade.php ENDPATH**/ ?>