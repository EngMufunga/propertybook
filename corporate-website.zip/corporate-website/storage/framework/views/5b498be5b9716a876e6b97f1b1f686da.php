

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Navigation Links</h1>
        <a href="<?php echo e(route('links.create')); ?>" class="btn btn-primary">Create New Navigation Link</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Text</th>
                    <th>URL</th>
                    <th>Order</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($link->text); ?></td>
                        <td><?php echo e($link->url); ?></td>
                        <td><?php echo e($link->order); ?></td>
                        <td>
                            <a href="<?php echo e(route('links.show', $link->id)); ?>" class="btn btn-info">Show</a>
                            <a href="<?php echo e(route('links.edit', $link->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('links.destroy', $link->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wilson Mufunga\Desktop\corporate-website\resources\views/navigation_links/index.blade.php ENDPATH**/ ?>