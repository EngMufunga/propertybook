<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 leading-tight">
      <?php echo e(__('Dashboard')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="container-fluid">
    <div class="row">
      <div class="col-md-3">
        <div class="list-group mb-3">
          <a href="<?php echo e(route('dashboard')); ?>" class="list-group-item list-group-item-action <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
            Dashboard
          </a>
          <a href="#" class="list-group-item list-group-item-action">
            Total Packages: <span class="badge bg-primary"><?php echo e($totalPackages); ?></span>
          </a>
          <a href="#" class="list-group-item list-group-item-action">
            Total Services: <span class="badge bg-success"><?php echo e($totalServices); ?></span>
          </a>

          <a href="<?php echo e(route('hero_section.index')); ?>" class="list-group-item list-group-item-action">Hero Section</a>
          <a href="<?php echo e(route('about_us_sections.index')); ?>" class="list-group-item list-group-item-action">Our Story Section</a>
          <a href="<?php echo e(route('services.index')); ?>" class="list-group-item list-group-item-action">Services Section</a>
          <a href="<?php echo e(route('packages.index')); ?>" class="list-group-item list-group-item-action">Packages Section</a>
          <a href="<?php echo e(route('footers.index')); ?>" class="list-group-item list-group-item-action">Call to Action Section</a>
        </div>
      </div>

      <div class="col-md-9">
        <div class="card-deck">
          <div class="card mb-3">
            <div class="card-header bg-primary text-white">
              Total Packages
            </div>
            <div class="card-body">
              <h5 class="card-title"><?php echo e($totalPackages); ?></h5>
            </div>
          </div>
          <div class="card mb-3">
            <div class="card-header bg-success text-white">
              Total Services
            </div>
            <div class="card-body">
              <h5 class="card-title"><?php echo e($totalServices); ?></h5>
            </div>
          </div>
        </div>

        <div class="mt-4">
          </div>
      </div>
    </div>
  </div>

  <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Wilson Mufunga\Desktop\corporate-website\resources\views/dashboard.blade.php ENDPATH**/ ?>