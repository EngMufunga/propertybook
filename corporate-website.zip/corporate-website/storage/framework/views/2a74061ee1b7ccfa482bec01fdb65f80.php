

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Hero Sections</h1>
        <a href="<?php echo e(route('hero_sections.create')); ?>" class="btn btn-primary">Create New Hero Section</a>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Button 1 Text</th>
                    <th>Button 1 URL</th>
                    <th>Button 2 Text</th>
                    <th>Button 2 URL</th>
                    <th>Image Path</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($section->title); ?></td>
                        <td><?php echo e($section->description); ?></td>
                        <td><?php echo e($section->button1_text); ?></td>
                        <td><?php echo e($section->button1_url); ?></td>
                        <td><?php echo e($section->button2_text); ?></td>
                        <td><?php echo e($section->button2_url); ?></td>
                        <td><?php echo e($section->image_path); ?></td>
                        <td>
                            <a href="<?php echo e(route('hero_sections.show', $section->id)); ?>" class="btn btn-info">Show</a>
                            <a href="<?php echo e(route('hero_sections.edit', $section->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('hero_sections.destroy', $section->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wilson Mufunga\Desktop\corporate-website\resources\views/hero_section/index.blade.php ENDPATH**/ ?>