<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ContentController;
use App\Http\Controllers\NavigationLinkController;
use App\Http\Controllers\HeroSectionController;
use App\Http\Controllers\AboutUsSectionController;
use App\Http\Controllers\AboutUsButtonController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\PackageController;
use App\Http\Controllers\PackageFeatureController;
use App\Http\Controllers\FooterController;


Route::get('/', function () {
    return view('frontend.index');
})->name('home');

Route::get('/navigation-links', [NavigationLinkController::class, 'index']);
Route::get('/hero-section', [HeroSectionController::class, 'index']);

Route::get('/services', [ServiceController::class, 'index']);
Route::get('/footers', [FooterController::class, 'index']);
Route::get('/about-us-sections', [AboutUsSectionController::class, 'index']);

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::resource('contents', ContentController::class);
    Route::resource('links', NavigationLinkController::class);
    Route::resource('hero_section', HeroSectionController::class);
    Route::resource('about_us_sections', AboutUsSectionController::class);
    Route::resource('about-us-buttons', AboutUsButtonController::class);
    Route::resource('services', ServiceController::class);
    Route::resource('packages', PackageController::class);
    Route::resource('features', PackageFeatureController::class);
    Route::resource('footers', FooterController::class);
});

require __DIR__.'/auth.php';
